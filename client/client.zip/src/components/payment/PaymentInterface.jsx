

import { useContext, useState } from "react";

import axios from "axios";
import { Context } from "../../context/Context";




function PaymentInterface() {
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');
  const [amt, setAmt] = useState('');
  
  const [ user, post ] = useContext(Context);




  const handleCardNumberChange = (event) => {
    setCardNumber(event.target.value);
    console.log(`${cardNumber}`);
  };
  console.log(`${cardNumber}`);
  const handleAmtChange = (event) => {
    setAmt(event.target.value);
  };

  const handleExpiryChange = (event) => {
    setExpiry(event.target.value);
  };

  const handleCvvChange = (event) => {
    setCvv(event.target.value);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const newPayment = {
      username: user.username,
      stud_username:post.username,
      post_title:post.title,
      payment_details:amt,
    };
    try {
      const res = await axios.post("/payment", newPayment);
      alert('Payment processed successfully!' + post.title);
      console.log(res);
          window.location.replace("/post/" + post.title);

    } catch (err) {}
    
  };

  return (
    <div>
      <h2>Payment Information</h2>
      <form onSubmit={handleSubmit}>
      <div>
          <label htmlFor="amt">amount</label>
          <input
            type="number"
            id="amt"
            name="amt"
            value={amt}
            onChange={handleAmtChange}
            required
          />
        </div>
        <div>
          <label htmlFor="cardNumber">Card Number:</label>
          <input
            type="text"
            id="cardNumber"
            name="cardNumber"
            value={cardNumber}
            onChange={handleCardNumberChange}
            required
          />
        </div>
        <div>
          <label htmlFor="expiry">Expiry Date:</label>
          <input
            type="text"
            id="expiry"
            name="expiry"
            value={expiry}
            onChange={handleExpiryChange}
            required
          />
        </div>
        <div>
          <label htmlFor="cvv">CVV:</label>
          <input
            type="text"
            id="cvv"
            name="cvv"
            value={cvv}
            onChange={handleCvvChange}
            required
          />
        </div>
        <button type="submit">Pay Now</button>
      </form>
    </div>
  );
  
}

export default PaymentInterface;
